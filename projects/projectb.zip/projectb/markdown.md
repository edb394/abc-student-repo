<h1>The Tab Tracker</h1>

I decided to make a browser extension that would help you keep track of how long you had been active on a tab for – you can set a time to be reminded to close the tab, which I envisioned could be used for checking to see if you currently still need the tab open.

I find that I leave tabs open for long periods of time, and I tried to create something that would help me combat that. This browser extension does that.